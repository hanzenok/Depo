package org.ganza.repo.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.ganza.repo.model.Repo;
import org.ganza.repo.model.RepoFile;
import org.ganza.repo.view.MainView;

public class Main {
	
	public static void main(String[] args) throws IOException{
		
		Repo repo = new Repo();
		
		repo.read();
		
//		repo.create();
//		repo.addFile(new RepoFile(new File("/home/gunza/Desktop/test"), null));
//		repo.write();
		
		System.out.println("Nb files: " + repo.size() + "\n");
		System.out.println(repo.list());
	}
	
}
