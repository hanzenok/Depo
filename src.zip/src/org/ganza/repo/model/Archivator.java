package org.ganza.repo.model;

public class Archivator {

}
