package org.ganza.repo.model;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;


/**
 * RepoFile répresent 
 * un fichier dans un dêpot
 * @author Ganza Mykhailo
 */

public class RepoFile
{	
	private File file;
	private File xml_file;
	
	/**
     * Constructeur principal
     * 
     * @param file
     * 			le fichier
     * 
     * @param xml_file
     * 			fichier xml associé
     */
	public RepoFile(File file, File xml_file) {
		
		this.file = file;
		this.xml_file = xml_file;
	}
	
	public void copy(String path) throws IOException{
		
		Files.copy(file.toPath(), Paths.get(path + "/" + file.getName()), StandardCopyOption.REPLACE_EXISTING);
	}
	
	/**
     * Renvoi le nom d'un fichier
     * 
     * @return le nom d'un fichier
     */
	public String getName()
	{	
		return file.getName();
	}
	
	/**
     * Renvoi le nom d'un fichier
     * 
     * @return le nom d'un fichier
     */
	public String toString()
	{	
		return getName();
	}
}
