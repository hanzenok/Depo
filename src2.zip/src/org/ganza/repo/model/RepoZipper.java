package org.ganza.repo.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class RepoZipper
{	
	private String archive_name;
	
	FileOutputStream fos;
	ZipOutputStream zos;
	
	public RepoZipper(String name) throws FileNotFoundException
	{
		this.archive_name = name;
		
		fos = new FileOutputStream(archive_name);
		zos = new ZipOutputStream(fos);
	}
	
	//add to zip
	public void add(File file) throws IOException
	{	
		FileInputStream fis = new FileInputStream(file);
		ZipEntry zipEntry = new ZipEntry(file.getName());
		zos.putNextEntry(zipEntry);

		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zos.write(bytes, 0, length);
		}

		zos.closeEntry();
		fis.close();
		
	}
	
	public void add(RepoFile rf) throws IOException
	{
		add(rf.getFile());
	}
	
	public void restore(){
		
//		try {
//			ZipFile zipFile = new ZipFile("test.zip");
//			Enumeration<?> enu = zipFile.entries();
//			while (enu.hasMoreElements()) {
//				ZipEntry zipEntry = (ZipEntry) enu.nextElement();
//
//				String name = zipEntry.getName();
//				long size = zipEntry.getSize();
//				long compressedSize = zipEntry.getCompressedSize();
//				System.out.printf("name: %-20s | size: %6d | compressed size: %6d\n", 
//						name, size, compressedSize);
//
//				File file = new File(name);
//				if (name.endsWith("/")) {
//					file.mkdirs();
//					continue;
//				}
//
//				File parent = file.getParentFile();
//				if (parent != null) {
//					parent.mkdirs();
//				}
//
//				InputStream is = zipFile.getInputStream(zipEntry);
//				FileOutputStream fos = new FileOutputStream(file);
//				byte[] bytes = new byte[1024];
//				int length;
//				while ((length = is.read(bytes)) >= 0) {
//					fos.write(bytes, 0, length);
//				}
//				is.close();
//				fos.close();
//
//			}
//			zipFile.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
	
	public void close() throws IOException{
		
		zos.close();
		fos.close();
	}
}
