package org.ganza.repo.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.ganza.repo.model.Repo;
import org.ganza.repo.model.RepoFile;
import org.ganza.repo.model.RepoZipper;
import org.ganza.repo.view.MainView;

import net.lingala.zip4j.exception.ZipException;

public class Main {
	
	public static void main(String[] args) throws IOException, ZipException{
		
		Repo repo = new Repo();
		
		repo.read();
		
//		repo.create();
//		repo.addFile(new RepoFile(new File("/home/gunza/Desktop/test"), null));
//		repo.write();
		
		System.out.println("Nb files: " + repo.size() + "\n");
		System.out.println(repo.list());
		
		repo.save("/tmp/TestRepo.repo");
		repo.load("/tmp/TestRepo.repo");
		

	}
	
}
